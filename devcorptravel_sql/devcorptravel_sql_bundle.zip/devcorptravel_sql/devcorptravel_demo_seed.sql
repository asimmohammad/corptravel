USE devcorptravel;
SET FOREIGN_KEY_CHECKS = 0;

INSERT IGNORE INTO organizations (external_id, name, domain, status, settings_json)
VALUES ('acme-001', 'Acme Corporation', 'acme.com', 'active', JSON_OBJECT('brandColor','#0ea5e9'));

SET @org_acme = (SELECT id FROM organizations WHERE external_id='acme-001');

INSERT IGNORE INTO roles (org_id, name) VALUES
(@org_acme, 'OrgAdmin'),
(@org_acme, 'TravelManager'),
(@org_acme, 'Arranger'),
(@org_acme, 'Traveler');

SET @r_admin_acme = (SELECT id FROM roles WHERE org_id=@org_acme AND name='OrgAdmin' LIMIT 1);
SET @r_mgr_acme   = (SELECT id FROM roles WHERE org_id=@org_acme AND name='TravelManager' LIMIT 1);
SET @r_arr_acme   = (SELECT id FROM roles WHERE org_id=@org_acme AND name='Arranger' LIMIT 1);
SET @r_trav_acme  = (SELECT id FROM roles WHERE org_id=@org_acme AND name='Traveler' LIMIT 1);

SET @p_policy_read   = (SELECT id FROM permissions WHERE code='policy.read');
SET @p_policy_write  = (SELECT id FROM permissions WHERE code='policy.write');
SET @p_policy_pub    = (SELECT id FROM permissions WHERE code='policy.publish');
SET @p_user_manage   = (SELECT id FROM permissions WHERE code='user.manage');
SET @p_arr_manage    = (SELECT id FROM permissions WHERE code='arranger.manage');
SET @p_trav_read     = (SELECT id FROM permissions WHERE code='traveler.read');
SET @p_trav_write    = (SELECT id FROM permissions WHERE code='traveler.write');
SET @p_prof_read     = (SELECT id FROM permissions WHERE code='profile.read');
SET @p_prof_write    = (SELECT id FROM permissions WHERE code='profile.write');
SET @p_search        = (SELECT id FROM permissions WHERE code='search.execute');
SET @p_book_create   = (SELECT id FROM permissions WHERE code='booking.create');
SET @p_book_cancel   = (SELECT id FROM permissions WHERE code='booking.cancel');
SET @p_trip_read     = (SELECT id FROM permissions WHERE code='trip.read');
SET @p_trip_write    = (SELECT id FROM permissions WHERE code='trip.write');
SET @p_report_read   = (SELECT id FROM permissions WHERE code='report.read');
SET @p_report_export = (SELECT id FROM permissions WHERE code='report.export');
SET @p_notify        = (SELECT id FROM permissions WHERE code='notifications.send');
SET @p_audit_read    = (SELECT id FROM permissions WHERE code='audit.read');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT @r_admin_acme, id FROM permissions;

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@r_mgr_acme, @p_policy_read),
(@r_mgr_acme, @p_policy_write),
(@r_mgr_acme, @p_policy_pub),
(@r_mgr_acme, @p_user_manage),
(@r_mgr_acme, @p_arr_manage),
(@r_mgr_acme, @p_trav_read),
(@r_mgr_acme, @p_trav_write),
(@r_mgr_acme, @p_prof_read),
(@r_mgr_acme, @p_prof_write),
(@r_mgr_acme, @p_search),
(@r_mgr_acme, @p_book_create),
(@r_mgr_acme, @p_book_cancel),
(@r_mgr_acme, @p_trip_read),
(@r_mgr_acme, @p_trip_write),
(@r_mgr_acme, @p_report_read),
(@r_mgr_acme, @p_report_export),
(@r_mgr_acme, @p_notify),
(@r_mgr_acme, @p_audit_read);

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@r_arr_acme, @p_trav_read),
(@r_arr_acme, @p_search),
(@r_arr_acme, @p_book_create),
(@r_arr_acme, @p_trip_read);

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@r_trav_acme, @p_search),
(@r_trav_acme, @p_book_create),
(@r_trav_acme, @p_trip_read),
(@r_trav_acme, @p_prof_read),
(@r_trav_acme, @p_prof_write);

INSERT IGNORE INTO users (org_id, email, display_name, status, auth_provider) VALUES
(@org_acme, 'admin@acme.com', 'Acme Admin', 'active', 'password'),
(@org_acme, 'tmgr@acme.com',  'Travel Manager', 'active', 'password'),
(@org_acme, 'arranger@acme.com', 'Acme Arranger', 'active', 'password'),
(@org_acme, 'traveler1@acme.com', 'Traveler One', 'active', 'password');

SET @u_admin  = (SELECT id FROM users WHERE org_id=@org_acme AND email='admin@acme.com');
SET @u_mgr    = (SELECT id FROM users WHERE org_id=@org_acme AND email='tmgr@acme.com');
SET @u_arr    = (SELECT id FROM users WHERE org_id=@org_acme AND email='arranger@acme.com');
SET @u_trav1  = (SELECT id FROM users WHERE org_id=@org_acme AND email='traveler1@acme.com');

INSERT IGNORE INTO user_roles (user_id, role_id) VALUES
(@u_admin, @r_admin_acme),
(@u_mgr,   @r_mgr_acme),
(@u_arr,   @r_arr_acme),
(@u_trav1, @r_trav_acme);

INSERT IGNORE INTO travelers (org_id, user_id, email, given_name, family_name, status)
VALUES (@org_acme, @u_trav1, 'traveler1@acme.com', 'Traveler', 'One', 'active');

SET @t_trav1 = (SELECT id FROM travelers WHERE org_id=@org_acme AND email='traveler1@acme.com');

INSERT IGNORE INTO loyalty_accounts (traveler_id, program_type, program_code, account_number) VALUES
(@t_trav1, 'air', 'AA', 'AA-1234567'),
(@t_trav1, 'hotel', 'MR', 'MR-7654321');

INSERT IGNORE INTO arranger_delegations (org_id, arranger_user_id, traveler_id, active)
VALUES (@org_acme, @u_arr, @t_trav1, 1);

INSERT IGNORE INTO policies (org_id, name, status, created_by)
VALUES (@org_acme, 'Global Default', 'draft', @u_admin);

SET @pol_g = (SELECT id FROM policies WHERE org_id=@org_acme AND name='Global Default');

INSERT IGNORE INTO policy_versions (policy_id, version_num, effective_from, status, created_by)
VALUES (@pol_g, 1, NOW(), 'published', @u_admin);

SET @polv1 = (SELECT id FROM policy_versions WHERE policy_id=@pol_g AND version_num=1);

INSERT IGNORE INTO policy_rules (policy_version_id, rule_key, rule_op, rule_value, sort_order) VALUES
(@polv1, 'hotel.max_nightly_rate', '<=', '250', 10),
(@polv1, 'flights.allowed_cabins', 'in', 'Economy,PremiumEconomy', 20);

SET FOREIGN_KEY_CHECKS = 1;
