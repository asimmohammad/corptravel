USE devcorptravel;
SET FOREIGN_KEY_CHECKS = 0;

SET @org_acme := (SELECT id FROM organizations WHERE external_id='acme-001' LIMIT 1);

DELETE FROM trips WHERE org_id = @org_acme;
DELETE FROM booking_items WHERE booking_id IN (SELECT id FROM bookings WHERE org_id = @org_acme);
DELETE FROM bookings WHERE org_id = @org_acme;
DELETE FROM notifications WHERE org_id = @org_acme;
DELETE FROM audit_logs WHERE org_id = @org_acme;

DELETE pr FROM policy_rules pr
JOIN policy_versions pv ON pv.id = pr.policy_version_id
JOIN policies p ON p.id = pv.policy_id
WHERE p.org_id = @org_acme;

DELETE pv FROM policy_versions pv
JOIN policies p ON p.id = pv.policy_id
WHERE p.org_id = @org_acme;

DELETE FROM policies WHERE org_id = @org_acme;

DELETE FROM arranger_delegations WHERE org_id = @org_acme;

DELETE la FROM loyalty_accounts la
JOIN travelers t ON t.id = la.traveler_id
WHERE t.org_id = @org_acme;

DELETE FROM travelers WHERE org_id = @org_acme;

DELETE ur FROM user_roles ur
JOIN roles r ON r.id = ur.role_id
WHERE r.org_id = @org_acme;

DELETE FROM roles WHERE org_id = @org_acme;

DELETE FROM users WHERE org_id = @org_acme;

DELETE FROM organizations WHERE id = @org_acme;

SET FOREIGN_KEY_CHECKS = 1;
