USE devcorptravel;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

INSERT IGNORE INTO lookup_status (status_key) VALUES
('active'),('inactive'),('deleted'),('draft'),('published'),
('pending'),('confirmed'),('canceled'),('completed');

INSERT IGNORE INTO lookup_mode (mode_key) VALUES
('flights'),('hotels'),('cars');

INSERT IGNORE INTO permissions (code) VALUES
('policy.read'),
('policy.write'),
('policy.publish'),
('user.manage'),
('role.manage'),
('arranger.manage'),
('traveler.read'),
('traveler.write'),
('profile.read'),
('profile.write'),
('search.execute'),
('booking.create'),
('booking.cancel'),
('trip.read'),
('trip.write'),
('report.read'),
('report.export'),
('notifications.send'),
('webhook.manage'),
('audit.read');

INSERT IGNORE INTO roles (org_id, name) VALUES
(NULL, 'OrgAdmin'),
(NULL, 'TravelManager'),
(NULL, 'Arranger'),
(NULL, 'Traveler');

SET @role_admin  = (SELECT id FROM roles WHERE org_id IS NULL AND name='OrgAdmin' LIMIT 1);
SET @role_mgr    = (SELECT id FROM roles WHERE org_id IS NULL AND name='TravelManager' LIMIT 1);
SET @role_arr    = (SELECT id FROM roles WHERE org_id IS NULL AND name='Arranger' LIMIT 1);
SET @role_trav   = (SELECT id FROM roles WHERE org_id IS NULL AND name='Traveler' LIMIT 1);

SET @p_policy_read   = (SELECT id FROM permissions WHERE code='policy.read');
SET @p_policy_write  = (SELECT id FROM permissions WHERE code='policy.write');
SET @p_policy_pub    = (SELECT id FROM permissions WHERE code='policy.publish');
SET @p_user_manage   = (SELECT id FROM permissions WHERE code='user.manage');
SET @p_role_manage   = (SELECT id FROM permissions WHERE code='role.manage');
SET @p_arr_manage    = (SELECT id FROM permissions WHERE code='arranger.manage');
SET @p_trav_read     = (SELECT id FROM permissions WHERE code='traveler.read');
SET @p_trav_write    = (SELECT id FROM permissions WHERE code='traveler.write');
SET @p_prof_read     = (SELECT id FROM permissions WHERE code='profile.read');
SET @p_prof_write    = (SELECT id FROM permissions WHERE code='profile.write');
SET @p_search        = (SELECT id FROM permissions WHERE code='search.execute');
SET @p_book_create   = (SELECT id FROM permissions WHERE code='booking.create');
SET @p_book_cancel   = (SELECT id FROM permissions WHERE code='booking.cancel');
SET @p_trip_read     = (SELECT id FROM permissions WHERE code='trip.read');
SET @p_trip_write    = (SELECT id FROM permissions WHERE code='trip.write');
SET @p_report_read   = (SELECT id FROM permissions WHERE code='report.read');
SET @p_report_export = (SELECT id FROM permissions WHERE code='report.export');
SET @p_notify        = (SELECT id FROM permissions WHERE code='notifications.send');
SET @p_webhook       = (SELECT id FROM permissions WHERE code='webhook.manage');
SET @p_audit_read    = (SELECT id FROM permissions WHERE code='audit.read');

INSERT IGNORE INTO role_permissions (role_id, permission_id)
SELECT @role_admin, id FROM permissions;

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@role_mgr, @p_policy_read),
(@role_mgr, @p_policy_write),
(@role_mgr, @p_policy_pub),
(@role_mgr, @p_user_manage),
(@role_mgr, @p_arr_manage),
(@role_mgr, @p_trav_read),
(@role_mgr, @p_trav_write),
(@role_mgr, @p_prof_read),
(@role_mgr, @p_prof_write),
(@role_mgr, @p_search),
(@role_mgr, @p_book_create),
(@role_mgr, @p_book_cancel),
(@role_mgr, @p_trip_read),
(@role_mgr, @p_trip_write),
(@role_mgr, @p_report_read),
(@role_mgr, @p_report_export),
(@role_mgr, @p_notify),
(@role_mgr, @p_audit_read);

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@role_arr, @p_trav_read),
(@role_arr, @p_search),
(@role_arr, @p_book_create),
(@role_arr, @p_trip_read);

INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES
(@role_trav, @p_search),
(@role_trav, @p_book_create),
(@role_trav, @p_trip_read),
(@role_trav, @p_prof_read),
(@role_trav, @p_prof_write);

SET FOREIGN_KEY_CHECKS = 1;
