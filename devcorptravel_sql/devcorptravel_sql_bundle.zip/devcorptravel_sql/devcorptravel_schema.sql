CREATE DATABASE IF NOT EXISTS devcorptravel
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE devcorptravel;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS lookup_status (
  status_key VARCHAR(40) PRIMARY KEY
) ENGINE=InnoDB;

INSERT IGNORE INTO lookup_status (status_key) VALUES
('active'),('inactive'),('deleted'),('draft'),('published'),
('pending'),('confirmed'),('canceled'),('completed');

CREATE TABLE IF NOT EXISTS lookup_mode (
  mode_key VARCHAR(20) PRIMARY KEY
) ENGINE=InnoDB;

INSERT IGNORE INTO lookup_mode (mode_key) VALUES
('flights'),('hotels'),('cars');

CREATE TABLE IF NOT EXISTS organizations (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  external_id   VARCHAR(64) UNIQUE,
  name          VARCHAR(200) NOT NULL,
  domain        VARCHAR(200),
  status        VARCHAR(40) NOT NULL DEFAULT 'active',
  settings_json JSON NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT ck_org_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS users (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id        BIGINT UNSIGNED NOT NULL,
  email         VARCHAR(254) NOT NULL,
  display_name  VARCHAR(200),
  status        VARCHAR(40) NOT NULL DEFAULT 'active',
  auth_provider VARCHAR(40) DEFAULT 'password',
  password_hash VARCHAR(255),
  meta_json     JSON NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY ux_users_org_email (org_id, email),
  CONSTRAINT fk_users_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT ck_users_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS roles (
  id        BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id    BIGINT UNSIGNED NULL,
  name      VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_roles_org_name (org_id, name),
  CONSTRAINT fk_roles_org FOREIGN KEY (org_id) REFERENCES organizations(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS permissions (
  id        BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  code      VARCHAR(120) NOT NULL UNIQUE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id      BIGINT UNSIGNED NOT NULL,
  permission_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (role_id, permission_id),
  CONSTRAINT fk_rp_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
  CONSTRAINT fk_rp_perm FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS user_roles (
  user_id BIGINT UNSIGNED NOT NULL,
  role_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY (user_id, role_id),
  CONSTRAINT fk_ur_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ur_role FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS travelers (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id        BIGINT UNSIGNED NOT NULL,
  user_id       BIGINT UNSIGNED NULL,
  email         VARCHAR(254) NOT NULL,
  given_name    VARCHAR(100),
  family_name   VARCHAR(100),
  phone         VARCHAR(40),
  status        VARCHAR(40) NOT NULL DEFAULT 'active',
  preferences_json JSON NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY ux_trav_org_email (org_id, email),
  CONSTRAINT fk_trav_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_trav_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT ck_trav_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS loyalty_accounts (
  id              BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  traveler_id     BIGINT UNSIGNED NOT NULL,
  program_type    VARCHAR(40) NOT NULL,
  program_code    VARCHAR(40) NOT NULL,
  account_number  VARCHAR(80) NOT NULL,
  meta_json       JSON NULL,
  created_at      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_loyalty_unique (traveler_id, program_type, program_code),
  CONSTRAINT fk_loyalty_trav FOREIGN KEY (traveler_id) REFERENCES travelers(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS arranger_delegations (
  id               BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id           BIGINT UNSIGNED NOT NULL,
  arranger_user_id BIGINT UNSIGNED NOT NULL,
  traveler_id      BIGINT UNSIGNED NOT NULL,
  active           TINYINT(1) NOT NULL DEFAULT 1,
  created_at       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_arranger (org_id, arranger_user_id, traveler_id),
  CONSTRAINT fk_arr_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_arr_user FOREIGN KEY (arranger_user_id) REFERENCES users(id),
  CONSTRAINT fk_arr_trav FOREIGN KEY (traveler_id) REFERENCES travelers(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS policies (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id        BIGINT UNSIGNED NOT NULL,
  name          VARCHAR(200) NOT NULL,
  status        VARCHAR(40) NOT NULL DEFAULT 'draft',
  created_by    BIGINT UNSIGNED NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY ux_policies_org_name (org_id, name),
  CONSTRAINT fk_pol_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_pol_user FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT ck_pol_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS policy_versions (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  policy_id     BIGINT UNSIGNED NOT NULL,
  version_num   INT NOT NULL,
  effective_from DATETIME NULL,
  effective_to   DATETIME NULL,
  status        VARCHAR(40) NOT NULL DEFAULT 'draft',
  created_by    BIGINT UNSIGNED NOT NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_polver_unique (policy_id, version_num),
  CONSTRAINT fk_polver_pol FOREIGN KEY (policy_id) REFERENCES policies(id) ON DELETE CASCADE,
  CONSTRAINT fk_polver_user FOREIGN KEY (created_by) REFERENCES users(id),
  CONSTRAINT ck_polver_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS policy_rules (
  id              BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  policy_version_id BIGINT UNSIGNED NOT NULL,
  rule_key        VARCHAR(120) NOT NULL,
  rule_op         VARCHAR(8) NOT NULL,
  rule_value      VARCHAR(255) NOT NULL,
  rule_json       JSON NULL,
  sort_order      INT DEFAULT 0,
  CONSTRAINT fk_polrule_ver FOREIGN KEY (policy_version_id) REFERENCES policy_versions(id) ON DELETE CASCADE,
  KEY idx_polrule_key (rule_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS bookings (
  id                BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id            BIGINT UNSIGNED NOT NULL,
  traveler_id       BIGINT UNSIGNED NOT NULL,
  arranger_user_id  BIGINT UNSIGNED NULL,
  status            VARCHAR(40) NOT NULL DEFAULT 'pending',
  policy_version_id BIGINT UNSIGNED NULL,
  policy_snapshot_json JSON NULL,
  total_amount      DECIMAL(12,2) NOT NULL DEFAULT 0,
  total_currency    CHAR(3) NOT NULL DEFAULT 'USD',
  confirmation_code VARCHAR(64) NULL,
  meta_json         JSON NULL,
  created_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_book_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_book_trav FOREIGN KEY (traveler_id) REFERENCES travelers(id),
  CONSTRAINT fk_book_arr FOREIGN KEY (arranger_user_id) REFERENCES users(id),
  CONSTRAINT fk_book_polver FOREIGN KEY (policy_version_id) REFERENCES policy_versions(id),
  CONSTRAINT ck_book_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS booking_items (
  id             BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  booking_id     BIGINT UNSIGNED NOT NULL,
  mode           VARCHAR(20) NOT NULL,
  supplier_ref   VARCHAR(200) NULL,
  is_in_policy   TINYINT(1) NOT NULL DEFAULT 1,
  price_amount   DECIMAL(12,2) NOT NULL,
  price_currency CHAR(3) NOT NULL DEFAULT 'USD',
  item_json      JSON NOT NULL,
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bi_booking FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
  CONSTRAINT ck_bi_mode FOREIGN KEY (mode) REFERENCES lookup_mode(mode_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS trips (
  id           BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id       BIGINT UNSIGNED NOT NULL,
  traveler_id  BIGINT UNSIGNED NOT NULL,
  booking_id   BIGINT UNSIGNED NOT NULL,
  start_date   DATE NOT NULL,
  end_date     DATE NOT NULL,
  status       VARCHAR(40) NOT NULL DEFAULT 'upcoming',
  trip_title   VARCHAR(200) NULL,
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_trip_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_trip_trav FOREIGN KEY (traveler_id) REFERENCES travelers(id),
  CONSTRAINT fk_trip_booking FOREIGN KEY (booking_id) REFERENCES bookings(id),
  CONSTRAINT ck_trip_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_logs (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id        BIGINT UNSIGNED NOT NULL,
  actor_user_id BIGINT UNSIGNED NULL,
  entity_type   VARCHAR(80) NOT NULL,
  entity_id     VARCHAR(80) NOT NULL,
  action        VARCHAR(80) NOT NULL,
  diff_json     JSON NULL,
  ip_address    VARBINARY(16) NULL,
  user_agent    VARCHAR(255) NULL,
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users(id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS notifications (
  id           BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  org_id       BIGINT UNSIGNED NOT NULL,
  user_id      BIGINT UNSIGNED NULL,
  traveler_id  BIGINT UNSIGNED NULL,
  channel      VARCHAR(20) NOT NULL,
  template_code VARCHAR(100) NOT NULL,
  payload_json JSON NOT NULL,
  status       VARCHAR(40) NOT NULL DEFAULT 'pending',
  created_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  sent_at      DATETIME NULL,
  CONSTRAINT fk_not_org FOREIGN KEY (org_id) REFERENCES organizations(id),
  CONSTRAINT fk_not_user FOREIGN KEY (user_id) REFERENCES users(id),
  CONSTRAINT fk_not_trav FOREIGN KEY (traveler_id) REFERENCES travelers(id),
  CONSTRAINT ck_not_status FOREIGN KEY (status) REFERENCES lookup_status(status_key)
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;
