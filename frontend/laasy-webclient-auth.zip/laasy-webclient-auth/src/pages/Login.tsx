import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { register, token } from '../lib/api'
import { useAuthStore } from '../store'

export default function Login(){
  const [email, setEmail] = useState('admin@acme.com')
  const [password, setPassword] = useState('secret')
  const [mode, setMode] = useState<'login'|'register'>('login')
  const [loading, setLoading] = useState(false)
  const nav = useNavigate()
  const { login } = useAuthStore()

  async function submit(e: React.FormEvent){
    e.preventDefault()
    setLoading(true)
    try{
      if(mode==='register'){ await register(email, password) }
      const u = await token(email, password)
      login(u)
      nav('/search/flights')
    }catch(err:any){
      alert(err?.message || 'error')
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="grid place-items-center h-screen">
      <form onSubmit={submit} className="card p-6 w-full max-w-md space-y-3">
        <h1 className="text-2xl font-bold">{mode==='login'?'Sign in':'Create account'}</h1>
        <div><label className="label">Email</label><input className="input" value={email} onChange={e=>setEmail(e.target.value)}/></div>
        <div><label className="label">Password</label><input type="password" className="input" value={password} onChange={e=>setPassword(e.target.value)}/></div>
        <button className="btn-primary w-full" disabled={loading}>{loading? 'Working…' : (mode==='login'?'Sign in':'Register & Sign in')}</button>
        <button type="button" className="text-sm text-primary" onClick={()=>setMode(mode==='login'?'register':'login')}>
          {mode==='login' ? 'Need an account? Register' : 'Have an account? Sign in'}
        </button>
      </form>
    </div>
  )
}
