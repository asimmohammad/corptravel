import { create } from 'zustand'
import type { User, Offer, Trip } from './types'
export const useAuthStore = create<{user:User|null;cart:Offer[];trips:Trip[];login:(u:User)=>void;logout:()=>void;setCart:(o:Offer[])=>void;setTrips:(t:Trip[])=>void}>(set=>({
  user: JSON.parse(localStorage.getItem('laasy_user')||'null'), cart:[], trips:[],
  login:(u)=>{ localStorage.setItem('laasy_user', JSON.stringify(u)); set({user:u}) },
  logout:()=>{ localStorage.removeItem('laasy_user'); set({user:null, cart:[], trips:[]}) },
  setCart:(o)=>set({cart:o}), setTrips:(t)=>set({trips:t})
}))
