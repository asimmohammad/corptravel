import { Routes, Route, Navigate, Link, useNavigate, Outlet } from 'react-router-dom'
import Login from './pages/Login'
import Search from './pages/Search'
import Results from './pages/Results'
import Checkout from './pages/Checkout'
import Confirmation from './pages/Confirmation'
import MyTrips from './pages/MyTrips'
import { useAuthStore } from './store'
export default function App(){ return (<Routes><Route path='/login' element={<Login/>}/><Route path='/' element={<Shell/>}><Route index element={<Navigate to='/search/flights' replace/>}/><Route path='search/:mode' element={<Search/>}/><Route path='results/:mode' element={<Results/>}/><Route path='checkout' element={<Checkout/>}/><Route path='confirmation/:id' element={<Confirmation/>}/><Route path='trips' element={<MyTrips/>}/></Route></Routes>) }
function Shell(){ const { user, logout }=useAuthStore(); const nav=useNavigate(); return (<div><header className='bg-white border-b'><div className='container mx-auto px-4 py-3 flex items-center gap-4'><Link to='/' className='text-xl font-bold'>LaaSy Travel</Link><nav className='flex items-center gap-3 text-sm'><Link to='/search/flights'>Book</Link><Link to='/trips'>My Trips</Link></nav><div className='ml-auto'>{user?<div className='flex items-center gap-3'><span className='text-sm text-gray-600'>{user.email} • {user.role}</span><button className='btn-secondary' onClick={logout}>Logout</button></div>:<button className='btn-primary' onClick={()=>nav('/login')}>Login</button>}</div></div></header><main><Outlet/></main></div>) }
