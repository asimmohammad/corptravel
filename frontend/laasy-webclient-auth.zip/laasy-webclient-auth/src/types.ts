export type Mode='flights'|'hotels'|'cars'
export interface User{ email:string; role:'OrgAdmin'|'Traveler'|'Arranger'|'TravelManager'; token:string }
export interface Offer{ id:string; mode:Mode; name:string; description?:string; price:number; currency:string; policyStatus:'in'|'out' }
export interface Trip{ id:string|number; traveler:string; segments:string[]; startDate:string; endDate:string; status:string }
