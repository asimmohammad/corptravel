import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { searchOffers } from '../lib/api'
import type { Mode, Offer } from '../types'
import FareCard from '../components/FareCard'
import { useAuthStore } from '../store'
export default function Results(){ const { mode }=useParams(); const m=(mode as Mode)??'flights'; const [offers,setOffers]=useState<Offer[]>([]); const [loading,setLoading]=useState(true); const nav=useNavigate(); const { setCart }=useAuthStore(); useEffect(()=>{ setLoading(true); searchOffers(m).then(setOffers).finally(()=>setLoading(false)) },[m]); return (<div className='grid-page space-y-3'><h2 className='text-xl font-semibold'>Results — {m}</h2>{loading?<p>Loading…</p>:offers.map(o=>(<FareCard key={o.id} {...o} onSelect={()=>{ setCart([o]); nav('/checkout') }}/>) )}</div>) }