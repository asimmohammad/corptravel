export type Mode='flights'|'hotels'|'cars'
export type Role='OrgAdmin'|'TravelManager'|'Arranger'|'Traveler'
export interface User{ email:string; role:Role; token:string }
export interface Offer{ id:string; mode:Mode; name:string; description?:string; price:number; currency:string; policyStatus:'in'|'out' }
export interface Trip{ id:string|number; traveler:string; segments:string[]; startDate:string; endDate:string; status:string }
export interface SpendPoint{ ym:string; total_usd:number }
export interface SpendReport{ currency:string; months:SpendPoint[] }
export interface ComplianceReport{ inPolicyRate:number; outPolicyRate:number; sample:number }
