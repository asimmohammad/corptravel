import type { Mode, Offer, Policy, PolicyRule, SearchParams, Trip, User } from '../types'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'
const MOCK = import.meta.env.VITE_MOCK_MODE === 'true'

function sleep(ms: number) { return new Promise(res => setTimeout(res, ms)) }

export async function login(email: string, password: string): Promise<User> {
  if (MOCK) {
    await sleep(500)
    return {
      email,
      role: email.endsWith('@laasy.com') ? 'OrgAdmin' : 'Traveler',
      token: 'fake-token'
    }
  }
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password })
  })
  if (!res.ok) throw new Error('Login failed')
  const data = await res.json()
  return { email, role: data.role, token: data.access_token }
}

export async function searchOffers(params: SearchParams): Promise<Offer[]> {
  if (MOCK) {
    await sleep(400)
    const base: Offer[] = Array.from({ length: 10 }).map((_, i) => ({
      id: `${params.mode}-${i}`,
      mode: params.mode,
      name: params.mode === 'flights' ? `Flight ${i + 1}` : params.mode === 'hotels' ? `Hotel ${i + 1}` : `Car ${i + 1}`,
      description: params.mode === 'flights' ? 'NONSTOP • 2h 10m' : undefined,
      price: Math.round(120 + Math.random() * 600),
      currency: 'USD',
      policyStatus: Math.random() > 0.25 ? 'in' : 'out'
    }))
    return base
  }
  const qs = new URLSearchParams(Object.entries(params as Record<string, string>))
  const res = await fetch(`${API_BASE}/search/${params.mode}?${qs.toString()}`)
  if (!res.ok) throw new Error('Search failed')
  return res.json()
}

export async function getPolicies(): Promise<Policy[]> {
  if (MOCK) {
    await sleep(200)
    return [
      { id: 1, name: 'Global Default', status: 'published', rules: [
        { key: 'hotel.max_nightly_rate', op: '<=', value: '250' },
        { key: 'flights.allowed_cabins', op: 'in', value: 'Economy,PremiumEconomy' }
      ] },
      { id: 2, name: 'Sales Team', status: 'draft', rules: [
        { key: 'hotel.max_nightly_rate', op: '<=', value: '300' }
      ] }
    ]
  }
  const res = await fetch(`${API_BASE}/policies`)
  if (!res.ok) throw new Error('Policies failed')
  return res.json()
}

export async function createPolicy(name: string, rules: PolicyRule[]): Promise<Policy> {
  if (MOCK) {
    await sleep(300)
    return { id: Math.floor(Math.random()*10000), name, status: 'draft', rules }
  }
  const res = await fetch(`${API_BASE}/policies`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, rules })
  })
  if (!res.ok) throw new Error('Create policy failed')
  return res.json()
}

export async function publishPolicy(id: number): Promise<Policy> {
  if (MOCK) {
    await sleep(300)
    return { id, name: 'New Policy', status: 'published', rules: [] }
  }
  const res = await fetch(`${API_BASE}/policies/${id}/publish`, { method: 'POST' })
  if (!res.ok) throw new Error('Publish failed')
  return res.json()
}

export async function getTrips(): Promise<Trip[]> {
  if (MOCK) {
    await sleep(200)
    const now = new Date()
    const d = (off: number) => new Date(now.getTime()+off*86400000).toISOString().slice(0,10)
    return [
      { id: 'T1', traveler: 'you@corp.com', segments: ['ORD→JFK', 'JFK→ORD'], startDate: d(7), endDate: d(10), status: 'upcoming' },
      { id: 'T2', traveler: 'you@corp.com', segments: ['ORD→SFO', 'SFO→ORD'], startDate: d(-30), endDate: d(-27), status: 'completed' }
    ]
  }
  const res = await fetch(`${API_BASE}/trips`)
  if (!res.ok) throw new Error('Trips failed')
  return res.json()
}

export async function postBookingConfirm(payload: any): Promise<{id: string}> {
  if (MOCK) {
    await sleep(400)
    return { id: 'CONF123456' }
  }
  const res = await fetch(`${API_BASE}/booking`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  if (!res.ok) throw new Error('Booking failed')
  return res.json()
}
