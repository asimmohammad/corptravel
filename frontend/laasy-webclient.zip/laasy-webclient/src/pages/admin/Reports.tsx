export default function Reports() {
  return (
    <div className="grid-page">
      <div className="card p-4">
        <h1 className="text-xl font-semibold">Reports</h1>
        <p className="text-gray-600">Stub page. Wire up to your warehouse (dbt models) for spend & compliance charts.</p>
      </div>
    </div>
  )
}
