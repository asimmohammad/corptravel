export default function Users() {
  return (
    <div className="grid-page">
      <div className="card p-4">
        <h1 className="text-xl font-semibold">Users & Roles</h1>
        <p className="text-gray-600">Stub page. Connect to your RBAC service to manage orgs, roles, and arrangers.</p>
      </div>
    </div>
  )
}
