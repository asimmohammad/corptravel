
import React from 'react'
import { logError, makeRequestId } from '../lib/logger'
type Props={ children: React.ReactNode }; type State={ hasError:boolean; rid:string }
export default class ErrorBoundary extends React.Component<Props, State>{
  constructor(p:Props){ super(p); this.state={ hasError:false, rid: makeRequestId() } }
  static getDerivedStateFromError(){ return { hasError:true } }
  componentDidCatch(error:any, info:any){ logError('react_error_boundary',{ requestId:this.state.rid, error:String(error), stack:info?.componentStack }) }
  render(){ if(this.state.hasError){ return <div className='grid place-items-center h-screen'><div className='card p-6'><h2 className='text-xl font-bold'>Something went wrong</h2><p className='text-sm'>Error id: {this.state.rid}</p></div></div> } return this.props.children }
}
