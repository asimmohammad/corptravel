
import type { Mode, Offer, Trip, User, SpendReport, ComplianceReport } from '../types'
import { makeRequestId, logInfo, logError } from './logger'
const API_BASE=import.meta.env.VITE_API_BASE||'http://localhost:8000'
const ORG_ID=import.meta.env.VITE_ORG_EXTERNAL_ID||'acme-001'
function authHeaders(){ const raw=localStorage.getItem('laasy_user'); const t=raw?(JSON.parse(raw) as User).token:null; const h:Record<string,string>={'X-Org-External-Id':ORG_ID}; if(t) h['Authorization']=`Bearer ${t}`; return h }
async function fx(url:string, init:RequestInit={}){ const reqId=makeRequestId(); const headers=new Headers(init.headers||{}); headers.set('X-Request-Id',reqId); const t0=performance.now(); const r=await fetch(url,{...init,headers}); const ms=Math.round(performance.now()-t0); const ctx={url,status:r.status,requestId:reqId,duration_ms:ms}; if(!r.ok) logError('api_error',ctx); else logInfo('api_ok',ctx); return r }
export async function register(email:string,password:string){ const fd=new FormData(); fd.append('email',email); fd.append('password',password); const r=await fx(`${API_BASE}/auth/register`,{method:'POST',headers:{'X-Org-External-Id':ORG_ID},body:fd}); if(!r.ok) throw new Error('register failed'); return r.json() }
export async function token(email:string,password:string){ const body=new URLSearchParams({username:email,password}); const r=await fx(`${API_BASE}/auth/token`,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-Org-External-Id':ORG_ID},body}); if(!r.ok) throw new Error('login failed'); const d=await r.json(); const u:User={ email, role:d.role, token:d.access_token }; return u }
export async function searchOffers(mode:Mode){ const r=await fx(`${API_BASE}/search/${mode}`,{headers:{...authHeaders()}}); if(!r.ok) throw new Error('search failed'); return r.json() }
export async function getTrips():Promise<Trip[]>{ const r=await fx(`${API_BASE}/trips`,{headers:{...authHeaders()}}); if(!r.ok) throw new Error('trips failed'); return r.json() }
export async function confirmBooking(traveler_email:string,items:{id:string,mode:Mode,price:number,currency:string}[]){ const r=await fx(`${API_BASE}/booking`,{method:'POST',headers:{'Content-Type':'application/json',...authHeaders()},body:JSON.stringify({traveler_email,items})}); if(!r.ok) throw new Error('booking failed'); return r.json() }
export async function getSpendReport():Promise<SpendReport>{ const r=await fx(`${API_BASE}/reports/spend`,{headers:{...authHeaders()}}); if(!r.ok) throw new Error('spend report failed'); return r.json() }
export async function getComplianceReport():Promise<ComplianceReport>{ const r=await fx(`${API_BASE}/reports/compliance`,{headers:{...authHeaders()}}); if(!r.ok) throw new Error('compliance report failed'); return r.json() }
