
import type { User } from "../types";
const ORG = import.meta.env.VITE_ORG_EXTERNAL_ID || "acme-001";
const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:8000";
export function makeRequestId(){ return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, c=>{ const r=(Math.random()*16)|0, v=c==='x'?r:(r&0x3)|0x8; return v.toString(16)}) }
export async function send(level:'info'|'warn'|'error', message:string, context?:Record<string,any>){
  try{ const h:Record<string,string>={"Content-Type":"application/json","X-Org-External-Id":ORG,"X-Request-Id":context?.requestId||makeRequestId()}; const raw=localStorage.getItem('laasy_user'); const t=raw?(JSON.parse(raw) as User).token:null; if(t) h['Authorization']=`Bearer ${t}`; await fetch(`${API_BASE}/logs`, { method:'POST', headers:h, body: JSON.stringify({level,message,context}) }) }catch{}
}
export const logInfo=(m:string,c?:Record<string,any>)=>{ console.info('[INFO]',m,c??''); return send('info',m,c) }
export const logError=(m:string,c?:Record<string,any>)=>{ console.error('[ERROR]',m,c??''); return send('error',m,c) }
