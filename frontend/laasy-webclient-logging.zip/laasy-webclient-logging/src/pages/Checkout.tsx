
import { useAuthStore } from '../store'
import { confirmBooking } from '../lib/api'
import { useNavigate } from 'react-router-dom'
export default function Checkout(){ const { cart, user }=useAuthStore(); const total=cart.reduce((s,c)=>s+c.price,0); const nav=useNavigate(); async function place(){ const r=await confirmBooking(user?.email||'traveler1@acme.com', cart.map(c=>({ id:c.id, mode:c.mode, price:c.price, currency:c.currency } as any))); nav(`/confirmation/${r.id}`) } return (<div className='grid-page'><div className='card p-4'><h3 className='font-semibold mb-2'>Checkout</h3><button className='btn-primary' onClick={place}>Confirm Booking</button><div className='mt-3 font-semibold'>Total: USD {total}</div></div></div>) }
