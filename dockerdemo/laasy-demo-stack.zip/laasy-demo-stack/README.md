# LaaSy Demo Stack (Docker Compose)
This spins up:
- MySQL 8.0 with `devcorptravel` schema + demo seed
- FastAPI backend (builds from ./backend)
- React web (builds from ./web)

## Usage
1) Unzip backend (laasy-backend-mysql-jwt.zip) into `./backend`
2) Unzip web (laasy-webclient-auth.zip) into `./web`
3) Run:
   ```bash
   docker compose up --build
   ```
   - Web: http://localhost:5173
   - API: http://localhost:8000/docs

Notes:
- MySQL password is `root` (dev only). Data is ephemeral unless you add a volume.
- Customize org id via `ORG_EXTERNAL_ID` and `VITE_ORG_EXTERNAL_ID`.
