
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from passlib.hash import bcrypt
from .config import JWT_SECRET, JWT_ALG, JWT_EXPIRE_MIN
oauth2_scheme=OAuth2PasswordBearer(tokenUrl="/auth/token")
def hash_password(p): return bcrypt.hash(p)
def verify_password(p,h): return bcrypt.verify(p,h)
def create_access_token(sub, org): return jwt.encode({"sub":sub,"org":org,"exp":datetime.now(tz=timezone.utc)+timedelta(minutes=JWT_EXPIRE_MIN)}, JWT_SECRET, algorithm=JWT_ALG)
def parse_token(t):
  try: return jwt.decode(t, JWT_SECRET, algorithms=[JWT_ALG])
  except JWTError: raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
def require_user(token: str = Depends(oauth2_scheme)): return parse_token(token)
