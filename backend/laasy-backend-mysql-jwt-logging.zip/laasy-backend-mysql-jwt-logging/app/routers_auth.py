
from fastapi import APIRouter, Depends, Header, HTTPException, status, Form
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from .db import get_db
from .models import User, UserRole, Role
from .utils import resolve_org
from .security import hash_password, verify_password, create_access_token
router=APIRouter()
@router.post('/register')
def register(email: str = Form(...), password: str = Form(...), db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id)
  u=db.query(User).filter(User.org_id==org.id, User.email==email).first()
  if u and u.password_hash: raise HTTPException(status_code=400, detail="User exists")
  if not u:
    u=User(org_id=org.id, email=email, display_name=email.split('@')[0], auth_provider='password')
    db.add(u); db.commit(); db.refresh(u)
  u.password_hash=hash_password(password); db.add(u); db.commit(); return {"ok":True, "user_id":u.id}
@router.post('/token')
def token(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id)
  u=db.query(User).filter(User.org_id==org.id, User.email==form.username).first()
  if not u or not u.password_hash or not verify_password(form.password,u.password_hash): raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
  role="Traveler"; ur=db.query(UserRole).filter(UserRole.user_id==u.id).first()
  if ur: r=db.query(Role).filter(Role.id==ur.role_id).first(); role=r.name if r else role
  elif u.email.endswith('@acme.com'): role='OrgAdmin'
  return {"access_token": create_access_token(sub=u.email, org=(x_org_external_id or 'acme-001')), "role": role, "org_external_id": (x_org_external_id or 'acme-001')}
