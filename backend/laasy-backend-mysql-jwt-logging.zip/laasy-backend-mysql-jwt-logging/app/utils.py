
from sqlalchemy.orm import Session
from .config import DEFAULT_ORG_EXTERNAL_ID
from .models import Organization
def resolve_org(db:Session, org_external_id:str|None):
  ext=org_external_id or DEFAULT_ORG_EXTERNAL_ID
  org=db.query(Organization).filter(Organization.external_id==ext).first()
  if not org: raise ValueError("Org not found")
  return org
