
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from sqlalchemy import text
from .db import get_db
from .utils import resolve_org
router=APIRouter()
@router.get('/spend')
def spend(db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id)
  sql=text("SELECT DATE_FORMAT(created_at,'%Y-%m') ym, SUM(total_amount) total_usd FROM bookings WHERE org_id=:oid GROUP BY ym ORDER BY ym DESC LIMIT 6")
  rows=db.execute(sql, {"oid":org.id}).mappings().all()
  return {"currency":"USD","months":[{"ym":r["ym"],"total_usd":float(r["total_usd"] or 0)} for r in rows]}
@router.get('/compliance')
def compliance(db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id)
  sql=text("SELECT SUM(CASE WHEN is_in_policy=1 THEN 1 ELSE 0 END) in_policy, COUNT(*) total FROM booking_items bi JOIN bookings b ON b.id=bi.booking_id WHERE b.org_id=:oid")
  r=db.execute(sql, {"oid":org.id}).mappings().first()
  ip=int(r['in_policy'] or 0); tot=int(r['total'] or 0); rate=(ip/tot) if tot else 0.0
  return {"inPolicyRate":rate,"outPolicyRate":1-rate,"sample":tot}
