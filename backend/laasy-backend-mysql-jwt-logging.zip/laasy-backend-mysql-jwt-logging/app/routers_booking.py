
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from datetime import date, timedelta
from .db import get_db
from .utils import resolve_org
from .models import Traveler, Booking, BookingItem, Trip
router=APIRouter()
@router.post('')
def book(payload:dict, db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id)
  email=payload.get('traveler_email','traveler@acme.com')
  trav=db.query(Traveler).filter(Traveler.org_id==org.id, Traveler.email==email).first()
  if not trav: trav=Traveler(org_id=org.id, email=email); db.add(trav); db.commit(); db.refresh(trav)
  items=payload.get('items',[]); total=sum(i.get('price',0) for i in items)
  b=Booking(org_id=org.id, traveler_id=trav.id, status='confirmed', total_amount=total, total_currency='USD')
  db.add(b); db.commit(); db.refresh(b)
  for i in items:
    db.add(BookingItem(booking_id=b.id, mode=i['mode'], is_in_policy=True, price_amount=i['price'], price_currency=i.get('currency','USD'), item_json=i))
  db.commit()
  t=Trip(org_id=org.id, traveler_id=trav.id, booking_id=b.id, start_date=date.today(), end_date=date.today()+timedelta(days=3), status='upcoming')
  db.add(t); db.commit()
  return {"id": f"CONF{b.id}"}
