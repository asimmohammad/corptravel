
from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from .db import get_db
from .utils import resolve_org
from .models import Policy, PolicyVersion, PolicyRule
router=APIRouter()
def load_rules(db, org_id):
  p=db.query(Policy).filter(Policy.org_id==org_id, Policy.status=='published').order_by(Policy.id.desc()).first()
  if not p: return {}
  pv=db.query(PolicyVersion).filter(PolicyVersion.policy_id==p.id).order_by(PolicyVersion.version_num.desc()).first()
  if not pv: return {}
  d={}
  for r in db.query(PolicyRule).filter(PolicyRule.policy_version_id==pv.id).all():
    d[r.rule_key]=(r.rule_op, r.rule_value)
  return d
def in_policy(mode, price, rules):
  if mode=='hotels' and 'hotel.max_nightly_rate' in rules:
    try: cap=float(rules['hotel.max_nightly_rate'][1])
    except: return True
    return price<=cap
  return True
def offers(mode, rules):
  out=[]
  for i in range(10):
    price=round(120+i*12.5,2)
    out.append({"id":f"{mode}-{i}","mode":mode,"name":("Flight" if mode=='flights' else 'Hotel' if mode=='hotels' else 'Car')+f" {i+1}","price":price,"currency":"USD","policyStatus":"in" if in_policy(mode,price,rules) else "out"})
  return out
@router.get('/flights')
def flights(db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id); return offers('flights', load_rules(db, org.id))
@router.get('/hotels')
def hotels(db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id); return offers('hotels', load_rules(db, org.id))
@router.get('/cars')
def cars(db:Session=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org=resolve_org(db, x_org_external_id); return offers('cars', load_rules(db, org.id))
