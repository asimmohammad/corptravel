
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import BigInteger, String, ForeignKey, JSON, DateTime, Date, Numeric, Boolean, CHAR
from sqlalchemy.sql import func
from .db import Base
class Organization(Base):
  __tablename__="organizations"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  external_id:Mapped[str|None]=mapped_column(String(64), unique=True)
  name:Mapped[str]=mapped_column(String(200))
class User(Base):
  __tablename__="users"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"))
  email:Mapped[str]=mapped_column(String(254))
  display_name:Mapped[str|None]=mapped_column(String(200))
  auth_provider:Mapped[str|None]=mapped_column(String(40))
  password_hash:Mapped[str|None]=mapped_column(String(255))
class Role(Base):
  __tablename__="roles"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int|None]=mapped_column(BigInteger, nullable=True)
  name:Mapped[str]=mapped_column(String(100))
class UserRole(Base):
  __tablename__="user_roles"
  user_id:Mapped[int]=mapped_column(ForeignKey("users.id"), primary_key=True)
  role_id:Mapped[int]=mapped_column(ForeignKey("roles.id"), primary_key=True)
class Traveler(Base):
  __tablename__="travelers"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"))
  user_id:Mapped[int|None]=mapped_column(ForeignKey("users.id"))
  email:Mapped[str]=mapped_column(String(254))
class Policy(Base):
  __tablename__="policies"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"))
  name:Mapped[str]=mapped_column(String(200))
  status:Mapped[str]=mapped_column(String(40))
class PolicyVersion(Base):
  __tablename__="policy_versions"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  policy_id:Mapped[int]=mapped_column(ForeignKey("policies.id"))
  version_num:Mapped[int]
  status:Mapped[str]=mapped_column(String(40))
class PolicyRule(Base):
  __tablename__="policy_rules"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  policy_version_id:Mapped[int]=mapped_column(ForeignKey("policy_versions.id"))
  rule_key:Mapped[str]=mapped_column(String(120))
  rule_op:Mapped[str]=mapped_column(String(8))
  rule_value:Mapped[str]=mapped_column(String(255))
class Booking(Base):
  __tablename__="bookings"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"))
  traveler_id:Mapped[int]=mapped_column(ForeignKey("travelers.id"))
  status:Mapped[str]=mapped_column(String(40))
  total_amount:Mapped[float]=mapped_column(Numeric(12,2), default=0)
  total_currency:Mapped[str]=mapped_column(CHAR(3), default="USD")
  created_at:Mapped[str]=mapped_column(DateTime, server_default=func.now())
class BookingItem(Base):
  __tablename__="booking_items"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  booking_id:Mapped[int]=mapped_column(ForeignKey("bookings.id"))
  mode:Mapped[str]=mapped_column(String(20))
  is_in_policy:Mapped[bool]=mapped_column(Boolean, default=True)
  price_amount:Mapped[float]=mapped_column(Numeric(12,2))
  price_currency:Mapped[str]=mapped_column(CHAR(3), default="USD")
  item_json:Mapped[dict]=mapped_column(JSON)
class Trip(Base):
  __tablename__="trips"
  id:Mapped[int]=mapped_column(BigInteger, primary_key=True, autoincrement=True)
  org_id:Mapped[int]=mapped_column(ForeignKey("organizations.id"))
  traveler_id:Mapped[int]=mapped_column(ForeignKey("travelers.id"))
  booking_id:Mapped[int]=mapped_column(ForeignKey("bookings.id"))
  start_date:Mapped[str]=mapped_column(Date)
  end_date:Mapped[str]=mapped_column(Date)
  status:Mapped[str]=mapped_column(String(40))
