
import logging, uuid, time
from fastapi import FastAPI, Request, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from .logging_setup import configure_logging, add_context
from .routers_auth import router as auth_router
from .routers_search import router as search_router
from .routers_booking import router as booking_router
from .routers_trips import router as trips_router
from .routers_reports import router as reports_router
from .security import require_user
from .db import get_db
from .utils import resolve_org

configure_logging()
log=logging.getLogger("api")

app=FastAPI(title="LaaSy API (Logging)", version="0.4.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

@app.middleware("http")
async def ctx(request: Request, call_next):
  rid=request.headers.get("X-Request-Id") or str(uuid.uuid4())
  start=time.time(); resp=None
  try:
    resp=await call_next(request); return resp
  finally:
    rec=logging.LogRecord("api", logging.INFO, __file__, 0, "request", args=(), exc_info=None)
    add_context(rec, request_id=rid, path=str(request.url), org=request.headers.get("X-Org-External-Id"))
    rec.msg={"event":"http_request","method":request.method,"path":request.url.path,"status":getattr(resp,'status_code',None),"duration_ms":int((time.time()-start)*1000)}
    log.handle(rec)

@app.get("/healthz")
def healthz(): return {"ok": True}

# public
app.include_router(auth_router, prefix="/auth", tags=["auth"])
# protected
app.include_router(search_router, prefix="/search", tags=["search"], dependencies=[Depends(require_user)])
app.include_router(booking_router, prefix="/booking", tags=["booking"], dependencies=[Depends(require_user)])
app.include_router(trips_router, prefix="/trips", tags=["trips"], dependencies=[Depends(require_user)])
app.include_router(reports_router, prefix="/reports", tags=["reports"], dependencies=[Depends(require_user)])

class ClientLog(BaseModel):
  level:str="info"; message:str; context:dict|None=None

@app.post("/logs")
def client_log(payload: ClientLog, request: Request, db=Depends(get_db), x_org_external_id: str | None = Header(None)):
  org_id=None
  try:
    org=resolve_org(db, x_org_external_id or request.headers.get("X-Org-External-Id")); org_id=org.external_id
  except: pass
  rec=logging.LogRecord("client", getattr(logging, payload.level.upper(), logging.INFO), __file__, 0, "client_log", args=(), exc_info=None)
  add_context(rec, request_id=request.headers.get("X-Request-Id"), path="/logs", org=org_id)
  rec.msg={"event":"client_log","message":payload.message,"context":payload.context}
  log.handle(rec); return {"ok": True}
