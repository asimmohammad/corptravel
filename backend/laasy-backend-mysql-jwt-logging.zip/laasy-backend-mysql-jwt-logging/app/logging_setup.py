
import logging, sys
from pythonjsonlogger import jsonlogger
def configure_logging():
  h=logging.StreamHandler(sys.stdout)
  f=jsonlogger.JsonFormatter('%(asctime)s %(levelname)s %(name)s %(message)s %(request_id)s %(path)s %(org)s')
  h.setFormatter(f)
  r=logging.getLogger()
  r.setLevel(logging.INFO)
  if not any(isinstance(x, logging.StreamHandler) for x in r.handlers):
    r.addHandler(h)
def add_context(rec, **k):
  for a,b in k.items(): setattr(rec,a,b)
  return rec
