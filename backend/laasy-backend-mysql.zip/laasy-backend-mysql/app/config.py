import os

DATABASE_URL = os.getenv("DATABASE_URL", "mysql+pymysql://root:root@127.0.0.1:3306/devcorptravel")
DEFAULT_ORG_EXTERNAL_ID = os.getenv("ORG_EXTERNAL_ID", "acme-001")
