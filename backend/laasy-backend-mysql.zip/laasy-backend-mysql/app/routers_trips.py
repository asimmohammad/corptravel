from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from .db import get_db
from .utils import resolve_org
from .models import Trip, Traveler
from .schemas import TripOut

router = APIRouter()

@router.get("", response_model=list[TripOut])
def list_trips(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    trips = db.query(Trip).filter(Trip.org_id == org.id).order_by(Trip.start_date.desc()).all()
    out = []
    for t in trips:
        trav = db.get(Traveler, t.traveler_id)
        out.append(TripOut(
            id=t.id,
            traveler=trav.email if trav else "",
            segments=[],
            startDate=str(t.start_date),
            endDate=str(t.end_date),
            status=t.status
        ))
    return out
