from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .utils import resolve_org
from .models import Traveler

router = APIRouter()

@router.get("")
def list_travelers(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    return db.query(Traveler).filter(Traveler.org_id == org.id).all()

@router.get("/{traveler_id}")
def get_traveler(traveler_id: int, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    t = db.get(Traveler, traveler_id)
    if not t:
        raise HTTPException(404, "Traveler not found")
    return t

@router.put("/{traveler_id}")
def update_traveler(traveler_id: int, body: dict, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    t = db.get(Traveler, traveler_id)
    if not t:
        raise HTTPException(404, "Traveler not found")
    for k, v in body.items():
        if hasattr(t, k):
            setattr(t, k, v)
    db.add(t); db.commit(); db.refresh(t)
    return t
