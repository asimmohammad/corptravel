from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from typing import List, Optional
from .db import get_db
from .schemas import Offer
from .utils import resolve_org
from .models import Policy, PolicyVersion, PolicyRule

router = APIRouter()

def load_policy_rules(db: Session, org_id: int) -> dict:
    p = db.query(Policy).filter(Policy.org_id == org_id, Policy.status == "published").order_by(Policy.id.desc()).first()
    if not p:
        return {}
    pv = db.query(PolicyVersion).filter(PolicyVersion.policy_id == p.id).order_by(PolicyVersion.version_num.desc()).first()
    if not pv:
        return {}
    rules = db.query(PolicyRule).filter(PolicyRule.policy_version_id == pv.id).all()
    d = {}
    for r in rules:
        d[r.rule_key] = (r.rule_op, r.rule_value)
    return d

def price_in_policy(mode: str, price: float, rules: dict) -> bool:
    if mode == "hotels" and "hotel.max_nightly_rate" in rules:
        op, val = rules["hotel.max_nightly_rate"]
        try:
            cap = float(val)
        except:
            return True
        return price <= cap if op in ("<=","==") else True
    return True

def gen_offers(mode: str, rules: dict) -> list[Offer]:
    offers = []
    for i in range(10):
        price = round(120 + i * 12.5, 2)
        in_policy = price_in_policy(mode, price, rules)
        offers.append(Offer(
            id=f"{mode}-{i}",
            mode=mode,  # type: ignore
            name=("Flight" if mode=="flights" else "Hotel" if mode=="hotels" else "Car") + f" {i+1}",
            price=price,
            currency="USD",
            policyStatus="in" if in_policy else "out",
            description="NONSTOP • 2h 10m" if mode=="flights" else None
        ))
    return offers

@router.get("/flights", response_model=list[Offer])
def flights(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    rules = load_policy_rules(db, org.id)
    return gen_offers("flights", rules)

@router.get("/hotels", response_model=list[Offer])
def hotels(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    rules = load_policy_rules(db, org.id)
    return gen_offers("hotels", rules)

@router.get("/cars", response_model=list[Offer])
def cars(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    rules = load_policy_rules(db, org.id)
    return gen_offers("cars", rules)
