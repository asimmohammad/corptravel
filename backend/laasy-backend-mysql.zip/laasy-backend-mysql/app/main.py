from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .routers_auth import router as auth_router
from .routers_policies import router as policies_router
from .routers_search import router as search_router
from .routers_booking import router as booking_router
from .routers_trips import router as trips_router
from .routers_travelers import router as travelers_router

app = FastAPI(title="LaaSy Corporate Travel API (MySQL Demo)", version="0.2.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/healthz")
def healthz():
    return {"ok": True}

app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.include_router(policies_router, prefix="/policies", tags=["policies"])
app.include_router(search_router, prefix="/search", tags=["search"])
app.include_router(booking_router, prefix="/booking", tags=["booking"])
app.include_router(trips_router, prefix="/trips", tags=["trips"])
app.include_router(travelers_router, prefix="/travelers", tags=["travelers"])
