from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from .db import get_db
from .models import User, Role, UserRole, Organization
from .schemas import LoginRequest, LoginResponse
from .utils import resolve_org

router = APIRouter()

@router.post("/login", response_model=LoginResponse)
def login(body: LoginRequest, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    user = db.query(User).filter(User.org_id == org.id, User.email == body.email).first()
    if not user:
        # auto-provision for demo
        user = User(org_id=org.id, email=body.email, display_name=body.email.split("@")[0], auth_provider="password")
        db.add(user)
        db.commit()
        db.refresh(user)

    # discover role (first match: org-scoped; fallback: domain-based)
    role = "Traveler"
    ur = db.query(UserRole).filter(UserRole.user_id == user.id).first()
    if ur:
        r = db.query(Role).filter(Role.id == ur.role_id).first()
        if r:
            role = r.name
    elif body.email.endswith("@acme.com"):
        role = "OrgAdmin"

    return LoginResponse(access_token="demo-jwt", role=role, org_external_id=org.external_id or "acme-001")
