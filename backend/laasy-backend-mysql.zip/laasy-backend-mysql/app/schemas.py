from pydantic import BaseModel, Field
from typing import List, Optional, Literal, Any

Mode = Literal['flights','hotels','cars']

class LoginRequest(BaseModel):
    email: str
    password: str | None = None

class LoginResponse(BaseModel):
    access_token: str
    role: str
    org_external_id: str

class PolicyRuleOut(BaseModel):
    rule_key: str
    rule_op: str
    rule_value: str

class PolicyOut(BaseModel):
    id: int
    name: str
    status: str
    rules: List[PolicyRuleOut] = []

class PolicyCreate(BaseModel):
    name: str
    rules: List[PolicyRuleOut] = []

class Offer(BaseModel):
    id: str
    mode: Mode
    name: str
    price: float
    currency: str = "USD"
    policyStatus: Literal['in','out'] = 'in'
    description: Optional[str] = None

class BookingItemIn(BaseModel):
    id: str
    mode: Mode
    price: float
    currency: str = "USD"
    details: dict = {}

class BookingRequest(BaseModel):
    traveler_email: str
    items: List[BookingItemIn]

class BookingResponse(BaseModel):
    id: str

class TripOut(BaseModel):
    id: int
    traveler: str
    segments: List[str] = []
    startDate: str
    endDate: str
    status: str
