# LaaSy Corporate Travel — FastAPI + MySQL (Demo)

This backend connects to **MySQL** and uses the `devcorptravel` schema you installed with the provided SQL bundle.

## Configure
Set env vars (or use a `.env` you load before running):
```
DATABASE_URL=mysql+pymysql://USER:PASS@HOST:3306/devcorptravel
ORG_EXTERNAL_ID=acme-001
```

## Run (local)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL="mysql+pymysql://root:root@127.0.0.1:3306/devcorptravel"
export ORG_EXTERNAL_ID="acme-001"
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
# http://localhost:8000/docs
```

## Docker
```bash
docker build -t laasy-backend-mysql .
docker run -p 8000:8000 -e DATABASE_URL="mysql+pymysql://root:root@host.docker.internal:3306/devcorptravel" -e ORG_EXTERNAL_ID=acme-001 laasy-backend-mysql
```

## API Highlights (demo)
- `POST /auth/login` — finds/creates user in org, returns a role (OrgAdmin if email ends with `@acme.com`).
- `GET/POST /policies` + `POST /policies/{id}/publish` — CRUD backed by MySQL tables.
- `GET /search/flights|hotels|cars` — mock offers evaluated against **published policy rules** (e.g., `hotel.max_nightly_rate`).
- `POST /booking` — creates `bookings` + `booking_items`, then a simple `trip` (today → today+3).
- `GET /trips` — lists trips for the org.
- `GET/PUT /travelers` — basic traveler CRUD.

> Scope to an org with the `X-Org-External-Id` header (defaults to `acme-001` for demo).

## Wire up the Web Client
Set web `.env`:
```
VITE_MOCK_MODE=false
VITE_API_BASE=http://localhost:8000
```
Run the web app — it will now hit this backend.
