from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from datetime import date, timedelta
from .db import get_db
from .utils import resolve_org
from .schemas import BookingRequest, BookingResponse
from .models import Traveler, Booking, BookingItem, Trip

router = APIRouter()

@router.post("", response_model=BookingResponse)
def create_booking(payload: BookingRequest, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    trav = db.query(Traveler).filter(Traveler.org_id == org.id, Traveler.email == payload.traveler_email).first()
    if not trav:
        # auto-provision traveler for demo
        trav = Traveler(org_id=org.id, user_id=None, email=payload.traveler_email, given_name="Demo", family_name="Traveler")
        db.add(trav); db.commit(); db.refresh(trav)

    total = sum(i.price for i in payload.items)
    booking = Booking(org_id=org.id, traveler_id=trav.id, arranger_user_id=None, status="confirmed",
                      total_amount=total, total_currency="USD", confirmation_code=None)
    db.add(booking); db.commit(); db.refresh(booking)

    for i in payload.items:
        db.add(BookingItem(booking_id=booking.id, mode=i.mode, supplier_ref=i.id, is_in_policy=True,
                           price_amount=i.price, price_currency=i.currency, item_json=i.details))
    db.commit()

    # create a simple trip window (today -> +3 days)
    today = date.today()
    trip = Trip(org_id=org.id, traveler_id=trav.id, booking_id=booking.id, start_date=today, end_date=today + timedelta(days=3), status="upcoming")
    db.add(trip); db.commit()

    return BookingResponse(id=f"CONF{booking.id}")
