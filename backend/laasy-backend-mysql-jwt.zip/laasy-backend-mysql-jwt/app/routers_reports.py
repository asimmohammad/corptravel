from fastapi import APIRouter, Depends, Header
from sqlalchemy.orm import Session
from sqlalchemy import text
from .db import get_db
from .utils import resolve_org
from .security import require_user

router = APIRouter()

@router.get("/spend")
def spend(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None), user=Depends(require_user)):
    org = resolve_org(db, x_org_external_id)
    # Monthly spend (last 6 months)
    sql = text("""
        SELECT DATE_FORMAT(created_at, '%Y-%m') AS ym,
               SUM(total_amount) AS total_usd
        FROM bookings
        WHERE org_id = :org_id AND status IN ('confirmed','completed')
        GROUP BY ym
        ORDER BY ym DESC
        LIMIT 6
    """)
    rows = db.execute(sql, {"org_id": org.id}).mappings().all()
    return {"currency": "USD", "months": rows}

@router.get("/compliance")
def compliance(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None), user=Depends(require_user)):
    org = resolve_org(db, x_org_external_id)
    sql = text("""
        SELECT
          SUM(CASE WHEN is_in_policy = 1 THEN 1 ELSE 0 END) AS in_policy,
          COUNT(*) AS total
        FROM booking_items bi
        JOIN bookings b ON b.id = bi.booking_id
        WHERE b.org_id = :org_id
    """)
    row = db.execute(sql, {"org_id": org.id}).mappings().first()
    in_pol = int(row["in_policy"] or 0)
    total = int(row["total"] or 0)
    return {"inPolicyRate": (in_pol/total) if total else 0.0, "outPolicyRate": (1 - (in_pol/total)) if total else 0.0, "sample": total}
