from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import jwt, JWTError
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from passlib.hash import bcrypt
from sqlalchemy.orm import Session
from .db import get_db
from .config import JWT_SECRET, JWT_ALG, JWT_EXPIRE_MIN
from .models import User, Organization
from .utils import resolve_org

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/token")

def hash_password(pw: str) -> str:
    return bcrypt.hash(pw)

def verify_password(pw: str, hash_: str) -> bool:
    return bcrypt.verify(pw, hash_)

def create_access_token(sub: str, org_external_id: str, expires_minutes: int = JWT_EXPIRE_MIN) -> str:
    to_encode = {"sub": sub, "org": org_external_id, "exp": datetime.now(tz=timezone.utc) + timedelta(minutes=expires_minutes)}
    return jwt.encode(to_encode, JWT_SECRET, algorithm=JWT_ALG)

def parse_token(token: str):
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")

def require_user(token: str = Depends(oauth2_scheme)) -> dict:
    payload = parse_token(token)
    return payload  # contains sub=email, org=external_id
