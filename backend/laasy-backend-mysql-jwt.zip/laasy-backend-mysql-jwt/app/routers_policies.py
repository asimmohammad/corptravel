from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session
from .db import get_db
from .models import Policy, PolicyVersion, PolicyRule
from .schemas import PolicyOut, PolicyCreate, PolicyRuleOut
from .utils import resolve_org

router = APIRouter()

@router.get("", response_model=list[PolicyOut])
def list_policies(db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    pols = db.query(Policy).filter(Policy.org_id == org.id).all()
    out = []
    for p in pols:
        # choose latest version rules
        pv = db.query(PolicyVersion).filter(PolicyVersion.policy_id == p.id).order_by(PolicyVersion.version_num.desc()).first()
        rules = []
        if pv:
            rlist = db.query(PolicyRule).filter(PolicyRule.policy_version_id == pv.id).all()
            rules = [PolicyRuleOut(rule_key=r.rule_key, rule_op=r.rule_op, rule_value=r.rule_value) for r in rlist]
        out.append(PolicyOut(id=p.id, name=p.name, status=p.status, rules=rules))
    return out

@router.post("", response_model=PolicyOut)
def create_policy(body: PolicyCreate, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    org = resolve_org(db, x_org_external_id)
    p = Policy(org_id=org.id, name=body.name, status="draft")
    db.add(p); db.commit(); db.refresh(p)
    pv = PolicyVersion(policy_id=p.id, version_num=1, status="draft")
    db.add(pv); db.commit(); db.refresh(pv)
    for r in body.rules:
        db.add(PolicyRule(policy_version_id=pv.id, rule_key=r.rule_key, rule_op=r.rule_op, rule_value=r.rule_value))
    db.commit()
    return PolicyOut(id=p.id, name=p.name, status=p.status, rules=body.rules)

@router.post("/{policy_id}/publish", response_model=PolicyOut)
def publish_policy(policy_id: int, db: Session = Depends(get_db), x_org_external_id: str | None = Header(None)):
    p = db.get(Policy, policy_id)
    if not p:
        raise HTTPException(404, "Policy not found")
    p.status = "published"
    db.commit()
    # return with current rules
    pv = db.query(PolicyVersion).filter(PolicyVersion.policy_id == p.id).order_by(PolicyVersion.version_num.desc()).first()
    rules = []
    if pv:
        rlist = db.query(PolicyRule).filter(PolicyRule.policy_version_id == pv.id).all()
        rules = [PolicyRuleOut(rule_key=r.rule_key, rule_op=r.rule_op, rule_value=r.rule_value) for r in rlist]
    return PolicyOut(id=p.id, name=p.name, status=p.status, rules=rules)
