# LaaSy Corporate Travel — FastAPI + MySQL + JWT + Alembic

Now includes:
- **JWT auth** (`/auth/register`, `/auth/token`) with bcrypt
- **Protected APIs** using OAuth2 bearer
- **Reports** from MySQL aggregates (`/reports/spend`, `/reports/compliance`)
- **SQLAlchemy models** for core tables
- **Alembic** configured for autogenerate-based diffs

## Run (local)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
export DATABASE_URL="mysql+pymysql://root:root@127.0.0.1:3306/devcorptravel"
export ORG_EXTERNAL_ID="acme-001"
export JWT_SECRET="change-me"
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

## Auth flow
1) Register a user (demo org via header):
```bash
curl -X POST http://localhost:8000/auth/register   -H 'X-Org-External-Id: acme-001'   -F 'email=admin@acme.com' -F 'password=secret'
```
2) Get a token:
```bash
curl -X POST http://localhost:8000/auth/token   -H 'X-Org-External-Id: acme-001'   -H 'Content-Type: application/x-www-form-urlencoded'   -d 'username=admin@acme.com&password=secret'
```
3) Call protected API with `Authorization: Bearer <TOKEN>`.

## Reports
- `GET /reports/spend` → last 6 months of booking spend (USD)
- `GET /reports/compliance` → in-policy vs total from `booking_items`

## Alembic (schema diffs for future changes)
```bash
# edit app/models.py to reflect new/changed tables or columns
alembic -x DATABASE_URL="$DATABASE_URL" revision --autogenerate -m "describe change"
alembic -x DATABASE_URL="$DATABASE_URL" upgrade head
```
> The current DB schema is created by your SQL bundle. Use Alembic for incremental changes going forward.

## Docker
```bash
docker build -t laasy-backend-mysql-jwt .
docker run -p 8000:8000   -e DATABASE_URL="mysql+pymysql://root:root@host.docker.internal:3306/devcorptravel"   -e ORG_EXTERNAL_ID=acme-001   -e JWT_SECRET=change-me   laasy-backend-mysql-jwt
```
