from fastapi import APIRouter
from typing import List
from datetime import date, timedelta
from ..models import Trip

router = APIRouter()

def mock_trips() -> List[Trip]:
    today = date.today()
    def d(days): return (today + timedelta(days=days)).isoformat()
    return [
        Trip(id="T1", traveler="you@corp.com", segments=["ORD→JFK","JFK→ORD"], startDate=d(7), endDate=d(10), status="upcoming"),
        Trip(id="T2", traveler="you@corp.com", segments=["ORD→SFO","SFO→ORD"], startDate=d(-30), endDate=d(-27), status="completed"),
    ]

@router.get("", response_model=List[Trip])
def list_trips():
    return mock_trips()
