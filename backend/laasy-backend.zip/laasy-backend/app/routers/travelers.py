from fastapi import APIRouter
from typing import Dict, Any

router = APIRouter()

TRAVELERS = {
    "1": {"id": "1", "name": "John Doe", "email": "john@corp.com", "loyalty": {"air":"", "hotel":"", "car":""}},
    "2": {"id": "2", "name": "Jane Doe", "email": "jane@corp.com", "loyalty": {"air":"", "hotel":"", "car":""}},
}

@router.get("")
def list_travelers():
    return list(TRAVELERS.values())

@router.get("/{traveler_id}")
def get_traveler(traveler_id: str):
    return TRAVELERS.get(traveler_id)

@router.put("/{traveler_id}")
def update_traveler(traveler_id: str, body: Dict[str, Any]):
    TRAVELERS[traveler_id] = {**TRAVELERS.get(traveler_id, {"id": traveler_id}), **body}
    return TRAVELERS[traveler_id]
