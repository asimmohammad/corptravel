from fastapi import APIRouter
from ..models import BookingRequest, BookingResponse

router = APIRouter()

@router.post("", response_model=BookingResponse)
def create_booking(req: BookingRequest):
    # A real impl would reserve and ticket with suppliers, store to DB, send notifications.
    return {"id": "CONF" + str(abs(hash(str(req))) % 10_000_000)}
