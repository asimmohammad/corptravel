from fastapi import APIRouter
from ..models import LoginRequest, LoginResponse

router = APIRouter()

@router.post("/login", response_model=LoginResponse)
def login(body: LoginRequest):
    role = "OrgAdmin" if body.email.endswith("@laasy.com") else "Traveler"
    return {"access_token": "fake-jwt-token", "role": role}
