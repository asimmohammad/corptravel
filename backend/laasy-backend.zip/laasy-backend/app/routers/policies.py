from fastapi import APIRouter, HTTPException
from typing import List
from ..models import Policy, PolicyCreate, PolicyRule

router = APIRouter()

POLICIES = {
    1: Policy(id=1, name="Global Default", status="published", rules=[
        PolicyRule(key="hotel.max_nightly_rate", op="<=", value="250"),
        PolicyRule(key="flights.allowed_cabins", op="in", value="Economy,PremiumEconomy")
    ]),
    2: Policy(id=2, name="Sales Team", status="draft", rules=[
        PolicyRule(key="hotel.max_nightly_rate", op="<=", value="300")
    ]),
}
COUNTER = 3

@router.get("", response_model=List[Policy])
def list_policies():
    return list(POLICIES.values())

@router.post("", response_model=Policy)
def create_policy(body: PolicyCreate):
    global COUNTER
    p = Policy(id=COUNTER, name=body.name, status="draft", rules=body.rules)
    POLICIES[COUNTER] = p
    COUNTER += 1
    return p

@router.post("/{policy_id}/publish", response_model=Policy)
def publish_policy(policy_id: int):
    p = POLICIES.get(policy_id)
    if not p:
        raise HTTPException(404, "Policy not found")
    p.status = "published"
    return p
