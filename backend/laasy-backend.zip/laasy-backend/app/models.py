from pydantic import BaseModel
from typing import List, Literal, Optional, Dict, Any

Mode = Literal["flights", "hotels", "cars"]

class LoginRequest(BaseModel):
    email: str
    password: str

class LoginResponse(BaseModel):
    access_token: str
    role: Literal["OrgAdmin", "Traveler", "Arranger", "TravelManager"]

class PolicyRule(BaseModel):
    key: str
    op: Literal["<=", "<", ">=", ">", "==", "in"]
    value: str

class Policy(BaseModel):
    id: int
    name: str
    status: Literal["draft", "published"]
    rules: List[PolicyRule]

class PolicyCreate(BaseModel):
    name: str
    rules: List[PolicyRule]

class Offer(BaseModel):
    id: str
    mode: Mode
    name: str
    description: Optional[str] = None
    price: float
    currency: str = "USD"
    policyStatus: Literal["in", "out"] = "in"
    details: Optional[Dict[str, Any]] = None

class SearchParams(BaseModel):
    mode: Mode
    origin: Optional[str] = None
    destination: Optional[str] = None
    departDate: Optional[str] = None
    returnDate: Optional[str] = None
    city: Optional[str] = None

class BookingItem(BaseModel):
    id: str
    mode: Mode
    price: float
    currency: str = "USD"

class BookingRequest(BaseModel):
    items: List[BookingItem]

class BookingResponse(BaseModel):
    id: str

class Trip(BaseModel):
    id: str
    traveler: str
    segments: List[str]
    startDate: str
    endDate: str
    status: Literal["upcoming", "completed", "canceled"]
